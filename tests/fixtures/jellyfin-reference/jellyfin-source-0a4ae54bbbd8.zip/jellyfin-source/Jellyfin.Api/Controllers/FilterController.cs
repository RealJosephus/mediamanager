using System;
using System.Linq;
using Jellyfin.Api.Helpers;
using Jellyfin.Api.ModelBinders;
using Jellyfin.Data.Enums;
using Jellyfin.Extensions;
using MediaBrowser.Controller.Dto;
using MediaBrowser.Controller.Entities;
using MediaBrowser.Controller.Library;
using MediaBrowser.Model.Dto;
using MediaBrowser.Model.Entities;
using MediaBrowser.Model.Globalization;
using MediaBrowser.Model.Querying;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Jellyfin.Api.Controllers;

/// <summary>
/// Filters controller.
/// </summary>
[Route("")]
[Authorize]
public class FilterController : BaseJellyfinApiController
{
    private readonly ILibraryManager _libraryManager;
    private readonly IUserManager _userManager;
    private readonly ILocalizationManager _localization;

    /// <summary>
    /// Initializes a new instance of the <see cref="FilterController"/> class.
    /// </summary>
    /// <param name="libraryManager">Instance of the <see cref="ILibraryManager"/> interface.</param>
    /// <param name="userManager">Instance of the <see cref="IUserManager"/> interface.</param>
    /// <param name="localization">Instance of the <see cref="ILocalizationManager"/> interface.</param>
    public FilterController(ILibraryManager libraryManager, IUserManager userManager, ILocalizationManager localization)
    {
        _libraryManager = libraryManager;
        _userManager = userManager;
        _localization = localization;
    }

    /// <summary>
    /// Gets legacy query filters.
    /// </summary>
    /// <param name="userId">Optional. User id.</param>
    /// <param name="parentId">Optional. Parent id.</param>
    /// <param name="includeItemTypes">Optional. If specified, results will be filtered based on item type. This allows multiple, comma delimited.</param>
    /// <param name="mediaTypes">Optional. Filter by MediaType. Allows multiple, comma delimited.</param>
    /// <response code="200">Legacy filters retrieved.</response>
    /// <returns>Legacy query filters.</returns>
    [HttpGet("Items/Filters")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public ActionResult<QueryFiltersLegacy> GetQueryFiltersLegacy(
        [FromQuery] Guid? userId,
        [FromQuery] Guid? parentId,
        [FromQuery, ModelBinder(typeof(CommaDelimitedCollectionModelBinder))] BaseItemKind[] includeItemTypes,
        [FromQuery, ModelBinder(typeof(CommaDelimitedCollectionModelBinder))] MediaType[] mediaTypes)
    {
        userId = RequestHelpers.GetUserId(User, userId);
        var user = userId.IsNullOrEmpty()
            ? null
            : _userManager.GetUserById(userId.Value);

        BaseItem? item = null;
        if (includeItemTypes.Length != 1
            || !(includeItemTypes[0] == BaseItemKind.Trailer
                 || includeItemTypes[0] == BaseItemKind.Program))
        {
            item = _libraryManager.GetParentItem(parentId, user?.Id);
        }

        if (item is not Folder folder)
        {
            return new QueryFiltersLegacy();
        }

        var query = new InternalItemsQuery(user)
        {
            MediaTypes = mediaTypes,
            IncludeItemTypes = includeItemTypes,
            Recursive = true,
            EnableTotalRecordCount = false,
            // Let LibraryManager scope virtual roots to the user's accessible libraries.
            AncestorIds = folder is UserRootFolder or AggregateFolder ? [] : [folder.Id],
            DtoOptions = new DtoOptions
            {
                Fields = [],
                EnableImages = false,
                EnableUserData = false
            }
        };

        return _libraryManager.GetQueryFiltersLegacy(query);
    }

    /// <summary>
    /// Gets query filters.
    /// </summary>
    /// <param name="userId">Optional. User id.</param>
    /// <param name="parentId">Optional. Specify this to localize the search to a specific item or folder. Omit to use the root.</param>
    /// <param name="includeItemTypes">Optional. If specified, results will be filtered based on item type. This allows multiple, comma delimited.</param>
    /// <param name="isAiring">Optional. Is item airing.</param>
    /// <param name="isMovie">Optional. Is item movie.</param>
    /// <param name="isSports">Optional. Is item sports.</param>
    /// <param name="isKids">Optional. Is item kids.</param>
    /// <param name="isNews">Optional. Is item news.</param>
    /// <param name="isSeries">Optional. Is item series.</param>
    /// <param name="recursive">Optional. Search recursive.</param>
    /// <response code="200">Filters retrieved.</response>
    /// <returns>Query filters.</returns>
    [HttpGet("Items/Filters2")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public ActionResult<QueryFilters> GetQueryFilters(
        [FromQuery] Guid? userId,
        [FromQuery] Guid? parentId,
        [FromQuery, ModelBinder(typeof(CommaDelimitedCollectionModelBinder))] BaseItemKind[] includeItemTypes,
        [FromQuery] bool? isAiring,
        [FromQuery] bool? isMovie,
        [FromQuery] bool? isSports,
        [FromQuery] bool? isKids,
        [FromQuery] bool? isNews,
        [FromQuery] bool? isSeries,
        [FromQuery] bool? recursive)
    {
        userId = RequestHelpers.GetUserId(User, userId);
        var user = userId.IsNullOrEmpty()
            ? null
            : _userManager.GetUserById(userId.Value);

        BaseItem? parentItem = null;
        if (includeItemTypes.Length == 1
            && (includeItemTypes[0] == BaseItemKind.Trailer
                || includeItemTypes[0] == BaseItemKind.Program))
        {
            parentItem = null;
        }
        else if (parentId.HasValue)
        {
            parentItem = _libraryManager.GetItemById<BaseItem>(parentId.Value);
        }

        var filters = new QueryFilters();
        var genreQuery = new InternalItemsQuery(user)
        {
            IncludeItemTypes = includeItemTypes,
            DtoOptions = new DtoOptions
            {
                Fields = Array.Empty<ItemFields>(),
                EnableImages = false,
                EnableUserData = false
            },
            IsAiring = isAiring,
            IsMovie = isMovie,
            IsSports = isSports,
            IsKids = isKids,
            IsNews = isNews,
            IsSeries = isSeries
        };

        var streamLanguageQuery = new InternalItemsQuery(user)
        {
            // Include alternate versions that may have additional languages.
            IncludeOwnedItems = true,
            IncludeItemTypes = includeItemTypes,
            DtoOptions = new DtoOptions
            {
                Fields = Array.Empty<ItemFields>(),
                EnableImages = false,
                EnableUserData = false
            },
            IsAiring = isAiring,
            IsMovie = isMovie,
            IsSports = isSports,
            IsKids = isKids,
            IsNews = isNews,
            IsSeries = isSeries
        };

        var itemQuery = new InternalItemsQuery(user)
        {
            IncludeItemTypes = includeItemTypes,
            DtoOptions = new DtoOptions
            {
                Fields = Array.Empty<ItemFields>(),
                EnableImages = false,
                EnableUserData = false
            },
            IsAiring = isAiring,
            IsMovie = isMovie,
            IsSports = isSports,
            IsKids = isKids,
            IsNews = isNews,
            IsSeries = isSeries
        };

        if ((recursive ?? true) || parentItem is UserView || parentItem is ICollectionFolder)
        {
            // Let LibraryManager scope virtual roots to the user's accessible libraries.
            Guid[] ancestorIds = parentItem is null or UserRootFolder or AggregateFolder ? [] : [parentItem.Id];
            genreQuery.AncestorIds = ancestorIds;
            streamLanguageQuery.AncestorIds = ancestorIds;
            itemQuery.AncestorIds = ancestorIds;
        }
        else
        {
            genreQuery.Parent = parentItem;
            streamLanguageQuery.Parent = parentItem;
            itemQuery.Parent = parentItem;
        }

        if ((includeItemTypes.Contains(BaseItemKind.Series) || includeItemTypes.Contains(BaseItemKind.Season))
            && !includeItemTypes.Contains(BaseItemKind.Episode))
        {
            // Series and season languages come from their episodes.
            streamLanguageQuery.IncludeItemTypes = [.. includeItemTypes, BaseItemKind.Episode];
        }

        if (includeItemTypes.Length == 1
            && (includeItemTypes[0] == BaseItemKind.MusicAlbum
                || includeItemTypes[0] == BaseItemKind.MusicVideo
                || includeItemTypes[0] == BaseItemKind.MusicArtist
                || includeItemTypes[0] == BaseItemKind.Audio))
        {
            filters.Genres = _libraryManager.GetMusicGenres(genreQuery).Items.Select(i => new NameGuidPair
            {
                Name = i.Item.Name,
                Id = i.Item.Id
            }).ToArray();
        }
        else
        {
            filters.Genres = _libraryManager.GetGenres(genreQuery).Items.Select(i => new NameGuidPair
            {
                Name = i.Item.Name,
                Id = i.Item.Id
            }).ToArray();
        }

        filters.Tags = _libraryManager.GetTagNames(itemQuery);
        filters.Years = _libraryManager.GetYears(itemQuery);
        filters.OfficialRatings = _libraryManager.GetOfficialRatings(itemQuery);

        if (includeItemTypes.Contains(BaseItemKind.Movie)
            || includeItemTypes.Contains(BaseItemKind.Series)
            || includeItemTypes.Contains(BaseItemKind.Season)
            || includeItemTypes.Contains(BaseItemKind.Episode))
        {
            filters.AudioLanguages = _libraryManager
                .GetMediaStreamLanguages(MediaStreamType.Audio, streamLanguageQuery)
                .Select(language =>
                {
                    var culture = _localization.FindLanguageInfo(language);
                    return new NameValuePair
                    {
                        Name = culture is null ? language : $"{culture.DisplayName} ({language})",
                        Value = language
                    };
                })
                .OrderBy(l => l.Name)
                .ToArray();
            filters.SubtitleLanguages = _libraryManager
                .GetMediaStreamLanguages(MediaStreamType.Subtitle, streamLanguageQuery)
                .Select(language =>
                {
                    var culture = _localization.FindLanguageInfo(language);
                    return new NameValuePair
                    {
                        Name = culture is null ? language : $"{culture.DisplayName} ({language})",
                        Value = language
                    };
                })
                .OrderBy(l => l.Name)
                .ToArray();
        }

        return filters;
    }
}
