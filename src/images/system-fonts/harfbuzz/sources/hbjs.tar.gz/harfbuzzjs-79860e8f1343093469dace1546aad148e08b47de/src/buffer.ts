import {
  Module,
  exports,
  track,
  hb_tag,
  utf8_ptr_to_string,
  string_to_ascii_ptr,
  string_to_utf16_ptr,
  type ValueOf,
} from "./helpers";
import type { GlyphInfo, GlyphPosition } from "./types";
import { Font } from "./font";

export const BufferContentType = {
  INVALID: 0,
  UNICODE: 1,
  GLYPHS: 2,
} as const;
export type BufferContentType = ValueOf<typeof BufferContentType>;

export const BufferSerializeFlag = {
  DEFAULT: 0x00000000,
  NO_CLUSTERS: 0x00000001,
  NO_POSITIONS: 0x00000002,
  NO_GLYPH_NAMES: 0x00000004,
  GLYPH_EXTENTS: 0x00000008,
  GLYPH_FLAGS: 0x00000010,
  NO_ADVANCES: 0x00000020,
  DEFINED: 0x0000003f,
} as const;
export type BufferSerializeFlag = ValueOf<typeof BufferSerializeFlag>;

export const BufferFlag = {
  DEFAULT: 0x00000000,
  BOT: 0x00000001,
  EOT: 0x00000002,
  PRESERVE_DEFAULT_IGNORABLES: 0x00000004,
  REMOVE_DEFAULT_IGNORABLES: 0x00000008,
  DO_NOT_INSERT_DOTTED_CIRCLE: 0x00000010,
  VERIFY: 0x00000020,
  PRODUCE_UNSAFE_TO_CONCAT: 0x00000040,
  PRODUCE_SAFE_TO_INSERT_TATWEEL: 0x00000080,
  DEFINED: 0x000000ff,
} as const;
export type BufferFlag = ValueOf<typeof BufferFlag>;

export const Direction = {
  INVALID: 0,
  LTR: 4,
  RTL: 5,
  TTB: 6,
  BTT: 7,
} as const;
export type Direction = ValueOf<typeof Direction>;

export const ClusterLevel = {
  MONOTONE_GRAPHEMES: 0,
  MONOTONE_CHARACTERS: 1,
  CHARACTERS: 2,
  GRAPHEMES: 3,
  DEFAULT: 0,
} as const;
export type ClusterLevel = ValueOf<typeof ClusterLevel>;

export const BufferSerializeFormat = {
  INVALID: 0,
  TEXT: hb_tag("TEXT"),
  JSON: hb_tag("JSON"),
} as const;
export type BufferSerializeFormat = ValueOf<typeof BufferSerializeFormat>;

/**
 * An object representing a {@link https://harfbuzz.github.io/harfbuzz-hb-buffer.html | HarfBuzz buffer}.
 * A buffer holds the input text and its properties before shaping, and the
 * output glyphs and their information after shaping.
 */
export class Buffer {
  readonly ptr: number;

  /**
   * @param existingPtr @internal Wrap an existing buffer pointer.
   */
  constructor(existingPtr?: number) {
    if (existingPtr != undefined) {
      this.ptr = exports.hb_buffer_reference(existingPtr);
    } else {
      this.ptr = exports.hb_buffer_create();
    }
    track(this, exports.hb_buffer_destroy);
  }

  /**
   * Appends a character with the Unicode value of `codePoint` to the buffer,
   * and gives it the initial cluster value of `cluster`. Clusters can be any
   * thing the client wants, they are usually used to refer to the index of the
   * character in the input text stream and are output in the `cluster` field
   * of {@link GlyphInfo}.
   *
   * This function does not check the validity of `codePoint`, it is up to the
   * caller to ensure it is a valid Unicode code point.
   * @param codePoint A Unicode code point.
   * @param cluster The cluster value of `codePoint`.
   */
  add(codePoint: number, cluster: number): void {
    exports.hb_buffer_add(this.ptr, codePoint, cluster);
  }

  /**
   * Add text to the buffer.
   * @param text Text to be added to the buffer.
   * @param itemOffset The offset of the first character to add to the buffer.
   * @param itemLength The number of characters to add to the buffer, or omit for the end of text.
   */
  addText(text: string, itemOffset: number = 0, itemLength?: number): void {
    const str = string_to_utf16_ptr(text);
    exports.hb_buffer_add_utf16(
      this.ptr,
      str.ptr,
      str.length,
      itemOffset,
      itemLength ?? str.length,
    );
    str.free();
  }

  /**
   * Add code points to the buffer.
   * @param codePoints Array of code points to be added to the buffer.
   * @param itemOffset The offset of the first code point to add to the buffer.
   * @param itemLength The number of code points to add to the buffer, or omit for the end of the array.
   */
  addCodePoints(
    codePoints: number[],
    itemOffset: number = 0,
    itemLength?: number,
  ): void {
    const codePointsPtr = exports.malloc(codePoints.length * 4);
    const codePointsArray = Module.HEAPU32.subarray(
      codePointsPtr / 4,
      codePointsPtr / 4 + codePoints.length,
    );
    codePointsArray.set(codePoints);
    exports.hb_buffer_add_codepoints(
      this.ptr,
      codePointsPtr,
      codePoints.length,
      itemOffset,
      itemLength ?? codePoints.length,
    );
    exports.free(codePointsPtr);
  }

  /**
   * Set buffer script, language and direction.
   *
   * This needs to be done before shaping.
   */
  guessSegmentProperties(): void {
    exports.hb_buffer_guess_segment_properties(this.ptr);
  }

  /**
   * Set buffer direction explicitly.
   * @param dir A {@link Direction} value.
   */
  setDirection(dir: Direction): void {
    exports.hb_buffer_set_direction(this.ptr, dir);
  }

  /**
   * Set buffer flags explicitly.
   * @param flags A combination of {@link BufferFlag} values (OR them together).
   */
  setFlags(flags: number): void {
    exports.hb_buffer_set_flags(this.ptr, flags);
  }

  /**
   * Set buffer language explicitly.
   * @param language The buffer language
   */
  setLanguage(language: string): void {
    const str = string_to_ascii_ptr(language);
    exports.hb_buffer_set_language(
      this.ptr,
      exports.hb_language_from_string(str.ptr, -1),
    );
    str.free();
  }

  /**
   * Set buffer script explicitly.
   * @param script The buffer script
   */
  setScript(script: string): void {
    const str = string_to_ascii_ptr(script);
    exports.hb_buffer_set_script(
      this.ptr,
      exports.hb_script_from_string(str.ptr, -1),
    );
    str.free();
  }

  /**
   * Set the HarfBuzz clustering level.
   *
   * Affects the cluster values returned from shaping.
   * @param level A {@link ClusterLevel} value. See the HarfBuzz manual chapter on Clusters.
   */
  setClusterLevel(level: ClusterLevel): void {
    exports.hb_buffer_set_cluster_level(this.ptr, level);
  }

  /** Reset the buffer to its initial status. */
  reset(): void {
    exports.hb_buffer_reset(this.ptr);
  }

  /**
   * Similar to reset(), but does not clear the Unicode functions and the
   * replacement code point.
   */
  clearContents(): void {
    exports.hb_buffer_clear_contents(this.ptr);
  }

  /**
   * Set message func.
   * @param func The function to set. It receives the buffer, font, and message
   * string as arguments. Returning false will skip this shaping step and move
   * to the next one.
   */
  setMessageFunc(
    func: (buffer: Buffer, font: Font, message: string) => boolean,
  ): void {
    const traceFunc = (
      bufferPtr: number,
      fontPtr: number,
      messagePtr: number,
      user_data: number,
    ) => {
      const message = utf8_ptr_to_string(messagePtr);
      const buffer = new Buffer(bufferPtr);
      const font = new Font(fontPtr);
      const result = func(buffer, font, message);
      return result ? 1 : 0;
    };
    const traceFuncPtr = Module.addFunction(traceFunc, "iiiii");
    exports.hb_buffer_set_message_func(this.ptr, traceFuncPtr, 0, 0);
  }

  /**
   * Get the the number of items in the buffer.
   * @returns The buffer length.
   */
  getLength(): number {
    return exports.hb_buffer_get_length(this.ptr);
  }

  /**
   * Get the glyph information from the buffer.
   * @returns An array of {@link GlyphInfo} objects.
   */
  getGlyphInfos(): GlyphInfo[] {
    const infosPtr = exports.hb_buffer_get_glyph_infos(this.ptr, 0);
    const infosArray = Module.HEAPU32.subarray(
      infosPtr / 4,
      infosPtr / 4 + this.getLength() * 5,
    );
    const infos: GlyphInfo[] = [];
    for (let i = 0; i < infosArray.length; i += 5) {
      infos.push({
        codepoint: infosArray[i],
        cluster: infosArray[i + 2],
        flags: exports.hb_glyph_info_get_glyph_flags(infosPtr + i * 4),
      });
    }
    return infos;
  }

  /**
   * Get the glyph positions from the buffer.
   * @returns An array of {@link GlyphPosition} objects.
   */
  getGlyphPositions(): GlyphPosition[] {
    const positionsPtr32 =
      exports.hb_buffer_get_glyph_positions(this.ptr, 0) / 4;
    if (positionsPtr32 == 0) {
      return [];
    }
    const positionsArray = Module.HEAP32.subarray(
      positionsPtr32,
      positionsPtr32 + this.getLength() * 5,
    );
    const positions: GlyphPosition[] = [];
    for (let i = 0; i < positionsArray.length; i += 5) {
      positions.push({
        xAdvance: positionsArray[i],
        yAdvance: positionsArray[i + 1],
        xOffset: positionsArray[i + 2],
        yOffset: positionsArray[i + 3],
      });
    }
    return positions;
  }

  /**
   * Get the glyph information and positions from the buffer.
   * @returns The glyph information and positions.
   *
   * The glyph information is returned as an array of objects with the
   * properties from getGlyphInfos and getGlyphPositions combined.
   */
  getGlyphInfosAndPositions(): (GlyphInfo & Partial<GlyphPosition>)[] {
    const infosPtr = exports.hb_buffer_get_glyph_infos(this.ptr, 0);
    const infosArray = Module.HEAPU32.subarray(
      infosPtr / 4,
      infosPtr / 4 + this.getLength() * 5,
    );

    const positionsPtr32 =
      exports.hb_buffer_get_glyph_positions(this.ptr, 0) / 4;
    const positionsArray = positionsPtr32
      ? Module.HEAP32.subarray(
          positionsPtr32,
          positionsPtr32 + this.getLength() * 5,
        )
      : undefined;

    const out: (GlyphInfo & Partial<GlyphPosition>)[] = [];
    for (let i = 0; i < infosArray.length; i += 5) {
      const info: GlyphInfo & Partial<GlyphPosition> = {
        codepoint: infosArray[i],
        cluster: infosArray[i + 2],
        flags: exports.hb_glyph_info_get_glyph_flags(infosPtr + i * 4),
      };
      for (const [name, idx] of [
        ["mask", 1],
        ["var1", 3],
        ["var2", 4],
      ] as [string, number][]) {
        Object.defineProperty(info, name, {
          value: infosArray[i + idx],
          enumerable: false,
        });
      }
      if (positionsArray) {
        info.xAdvance = positionsArray[i];
        info.yAdvance = positionsArray[i + 1];
        info.xOffset = positionsArray[i + 2];
        info.yOffset = positionsArray[i + 3];
        Object.defineProperty(info, "var", {
          value: positionsArray[i + 4],
          enumerable: false,
        });
      }
      out.push(info);
    }
    return out;
  }

  /**
   * Update the glyph positions in the buffer.
   * WARNING: Do not use unless you know what you are doing.
   */
  updateGlyphPositions(positions: GlyphPosition[]): void {
    const positionsPtr32 =
      exports.hb_buffer_get_glyph_positions(this.ptr, 0) / 4;
    if (positionsPtr32 == 0) {
      return;
    }
    const len = Math.min(positions.length, this.getLength());
    const positionsArray = Module.HEAP32.subarray(
      positionsPtr32,
      positionsPtr32 + len * 5,
    );
    for (let i = 0; i < len; i++) {
      positionsArray[i * 5] = positions[i].xAdvance;
      positionsArray[i * 5 + 1] = positions[i].yAdvance;
      positionsArray[i * 5 + 2] = positions[i].xOffset;
      positionsArray[i * 5 + 3] = positions[i].yOffset;
    }
  }

  /**
   * Serialize the buffer contents to a string.
   * @param options Serialization options:
   *  - `font`: the font to use for serialization;
   *  - `start`: the starting index of the glyphs (default `0`);
   *  - `end`: the ending index of the glyphs (default end of buffer);
   *  - `format`: a {@link BufferSerializeFormat} value (default `TEXT`);
   *  - `flags`: a combination of {@link BufferSerializeFlag} values (default `0`).
   * @returns The serialized buffer contents.
   */
  serialize(
    options: {
      font?: Font;
      start?: number;
      end?: number;
      format?: BufferSerializeFormat;
      flags?: number;
    } = {},
  ): string {
    let {
      font,
      start = 0,
      end,
      format = BufferSerializeFormat.TEXT,
      flags = 0,
    } = options;
    const sp = Module.stackSave();
    const endPos = end ?? this.getLength();
    const bufLen = 32 * 1024;
    const bufPtr = exports.malloc(bufLen);
    const bufConsumedPtr = Module.stackAlloc(4);
    let result = "";
    while (start < endPos) {
      start += exports.hb_buffer_serialize(
        this.ptr,
        start,
        endPos,
        bufPtr,
        bufLen,
        bufConsumedPtr,
        font ? font.ptr : 0,
        format,
        flags,
      );
      const bufConsumed = Module.HEAPU32[bufConsumedPtr / 4];
      if (bufConsumed == 0) break;
      result += utf8_ptr_to_string(bufPtr, bufConsumed);
    }
    exports.free(bufPtr);
    Module.stackRestore(sp);
    return result;
  }

  /**
   * Return the buffer content type.
   *
   * @returns The buffer content type as a {@link BufferContentType} value.
   */
  getContentType(): BufferContentType {
    return exports.hb_buffer_get_content_type(this.ptr) as BufferContentType;
  }
}
