import { defineConfig } from "tsdown";

export default defineConfig({
  entry: ["src/index.ts"],
  format: ["esm"],
  dts: true,
  clean: false,
  outDir: "dist",
  deps: { neverBundle: ["./harfbuzz.js"] },
  copy: ["src/harfbuzz.d.ts"],
});
