package hf_aggregate

import (
	"github.com/alist-org/alist/v3/internal/driver"
	"github.com/alist-org/alist/v3/internal/op"
)

type Addition struct {
	ManifestPath string `json:"manifest_path" required:"true" help:"Path to a JSONL manifest. Each line contains path, repo_type, repo, token, and optional branch."`
	BaseURL      string `json:"base_url" default:"http://127.0.0.1:23678"`
	Branch       string `json:"branch" default:"main"`
}

var config = driver.Config{
	Name:              "HuggingFaceAggregate",
	LocalSort:         true,
	OnlyLocal:         false,
	OnlyProxy:         false,
	NoCache:           true,
	NoUpload:          true,
	NeedMs:            false,
	DefaultRoot:       "/",
	CheckStatus:       true,
	Alert:             "",
	NoOverwriteUpload: false,
}

func init() {
	op.RegisterDriver(func() driver.Driver {
		return &HuggingFaceAggregate{}
	})
}
