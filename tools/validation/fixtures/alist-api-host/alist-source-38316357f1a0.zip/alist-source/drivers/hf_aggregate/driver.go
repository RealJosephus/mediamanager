package hf_aggregate

import (
	"bufio"
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"os"
	stdpath "path"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/alist-org/alist/v3/internal/driver"
	"github.com/alist-org/alist/v3/internal/errs"
	"github.com/alist-org/alist/v3/internal/model"
	"github.com/alist-org/alist/v3/pkg/utils"
	"github.com/go-resty/resty/v2"
	"github.com/pkg/errors"
)

type HuggingFaceAggregate struct {
	model.Storage
	Addition
	client *resty.Client

	mutex            sync.RWMutex
	repos            []*manifestRepo
	root             *mountNode
	manifestModTime  time.Time
	manifestSize     int64
	treeCache        map[string][]hfTreeEntry
	missingTreeCache map[string]struct{}
	objectCache      map[string]repoMatch
}

type manifest struct {
	Repos []manifestRepo
}

type manifestRepo struct {
	Path     string `json:"path"`
	RepoType string `json:"repo_type"`
	Repo     string `json:"repo"`
	Token    string `json:"token"`
	Branch   string `json:"branch"`

	localMountPath string
	seq            int
}

type mountNode struct {
	name     string
	children map[string]*mountNode
	repos    []*manifestRepo
}

type hfTreeEntry struct {
	Type string `json:"type"`
	Oid  string `json:"oid"`
	Size int64  `json:"size"`
	Path string `json:"path"`
}

func (d *HuggingFaceAggregate) Config() driver.Config {
	return config
}

func (d *HuggingFaceAggregate) GetAddition() driver.Additional {
	return &d.Addition
}

func (d *HuggingFaceAggregate) Init(ctx context.Context) error {
	if d.ManifestPath == "" {
		return errors.New("manifest_path is required")
	}
	if d.BaseURL == "" {
		d.BaseURL = "http://127.0.0.1:23678"
	}
	if d.Branch == "" {
		d.Branch = "main"
	}
	d.client = resty.New().
		SetBaseURL(strings.TrimRight(d.BaseURL, "/")).
		SetHeader("User-Agent", "alist")
	return d.reloadManifest()
}

func (d *HuggingFaceAggregate) Drop(ctx context.Context) error {
	return nil
}

func (d *HuggingFaceAggregate) GetRoot(ctx context.Context) (model.Obj, error) {
	return &model.Object{
		Path:     "/",
		Name:     "root",
		Size:     0,
		Modified: d.GetStorage().Modified,
		IsFolder: true,
	}, nil
}

func (d *HuggingFaceAggregate) Get(ctx context.Context, reqPath string) (model.Obj, error) {
	if err := d.ensureManifestFresh(); err != nil {
		return nil, err
	}
	reqPath = utils.FixAndCleanPath(reqPath)
	d.mutex.RLock()
	if node := d.getNode(reqPath); node != nil {
		d.mutex.RUnlock()
		return nodeToObj(node, reqPath, d.GetStorage().Modified), nil
	}
	matches := d.matchRepos(reqPath)
	if match, ok := d.objectCache[reqPath]; ok && matchInRepos(match, matches) {
		d.mutex.RUnlock()
		if obj, err := d.getRepoObj(ctx, match, reqPath); err == nil {
			return obj, nil
		}
		d.mutex.Lock()
		delete(d.objectCache, reqPath)
		d.mutex.Unlock()
		d.mutex.RLock()
	}
	d.mutex.RUnlock()
	if len(matches) == 0 {
		return nil, errs.ObjectNotFound
	}
	for _, match := range matches {
		obj, err := d.getRepoObj(ctx, match, reqPath)
		if err == nil {
			d.setObjectCache(reqPath, match)
			return obj, nil
		}
	}
	return nil, errs.ObjectNotFound
}

func (d *HuggingFaceAggregate) List(ctx context.Context, dir model.Obj, args model.ListArgs) ([]model.Obj, error) {
	if err := d.ensureManifestFresh(); err != nil {
		return nil, err
	}
	reqPath := utils.FixAndCleanPath(dir.GetPath())
	d.mutex.RLock()
	node := d.getNode(reqPath)
	matches := d.matchRepos(reqPath)
	if node == nil && len(matches) == 0 {
		d.mutex.RUnlock()
		return nil, errs.ObjectNotFound
	}

	objs := make([]model.Obj, 0)
	names := make(map[string]struct{})
	if node != nil {
		childNames := make([]string, 0, len(node.children))
		for name := range node.children {
			childNames = append(childNames, name)
		}
		sort.Strings(childNames)
		for _, name := range childNames {
			child := node.children[name]
			objs = append(objs, nodeToObj(child, stdpath.Join(reqPath, name), d.GetStorage().Modified))
			names[name] = struct{}{}
		}
	}
	d.mutex.RUnlock()

	for _, match := range matches {
		entries, ok, err := d.listExistingDir(ctx, match.repo, match.repoPath, args.Refresh)
		if err != nil || !ok {
			continue
		}
		for _, entry := range entries {
			name := stdpath.Base(entry.Path)
			if _, ok := names[name]; ok {
				continue
			}
			objs = append(objs, d.entryToObj(match.repo, entry))
			names[name] = struct{}{}
			d.setObjectCache(stdpath.Join(match.repo.localMountPath, entry.Path), repoMatch{
				repo:     match.repo,
				repoPath: utils.FixAndCleanPath(entry.Path),
			})
		}
	}
	return objs, nil
}

func (d *HuggingFaceAggregate) Link(ctx context.Context, file model.Obj, args model.LinkArgs) (*model.Link, error) {
	if err := d.ensureManifestFresh(); err != nil {
		return nil, err
	}
	d.mutex.RLock()
	matches := d.matchRepos(file.GetPath())
	d.mutex.RUnlock()
	if len(matches) == 0 {
		return nil, errs.ObjectNotFound
	}
	if file.IsDir() {
		return nil, errs.NotFile
	}
	var repo *manifestRepo
	var repoPath string
	d.mutex.RLock()
	if match, ok := d.objectCache[utils.FixAndCleanPath(file.GetPath())]; ok && matchInRepos(match, matches) {
		repo = match.repo
		repoPath = match.repoPath
	}
	d.mutex.RUnlock()
	for _, match := range matches {
		if repo != nil {
			break
		}
		parentPath, name := stdpath.Split(match.repoPath)
		if name == "" {
			continue
		}
		entries, ok, err := d.listExistingDir(ctx, match.repo, parentPath)
		if err != nil || !ok {
			continue
		}
		for _, entry := range entries {
			if entry.Type != "directory" && stdpath.Base(entry.Path) == name {
				repo = match.repo
				repoPath = match.repoPath
				d.setObjectCache(utils.FixAndCleanPath(file.GetPath()), match)
				break
			}
		}
		if repo != nil {
			break
		}
	}
	if repo == nil {
		return nil, errs.ObjectNotFound
	}
	filePath := strings.TrimPrefix(utils.FixAndCleanPath(repoPath), "/")
	repoType := normalizeRepoType(repo.RepoType)
	branch := d.branch(repo)

	var downloadURL string
	if repoType == "datasets" {
		downloadURL = fmt.Sprintf("%s/datasets/%s/resolve/%s/%s", strings.TrimRight(d.BaseURL, "/"), repo.Repo, branch, url.PathEscape(filePath))
	} else {
		downloadURL = fmt.Sprintf("%s/%s/resolve/%s/%s", strings.TrimRight(d.BaseURL, "/"), repo.Repo, branch, url.PathEscape(filePath))
	}
	link := &model.Link{
		URL:      downloadURL,
		Header:   http.Header{},
		PartSize: 8 * utils.MB,
	}
	if token := d.token(repo); token != "" {
		link.Header.Set("Authorization", fmt.Sprintf("Bearer %s", token))
	}
	return link, nil
}

func (d *HuggingFaceAggregate) ensureManifestFresh() error {
	info, err := os.Stat(d.ManifestPath)
	if err != nil {
		return errors.Wrap(err, "failed to stat manifest")
	}
	d.mutex.RLock()
	fresh := info.ModTime().Equal(d.manifestModTime) && info.Size() == d.manifestSize
	d.mutex.RUnlock()
	if fresh {
		return nil
	}
	return d.reloadManifest()
}

func (d *HuggingFaceAggregate) reloadManifest() error {
	info, err := os.Stat(d.ManifestPath)
	if err != nil {
		return errors.Wrap(err, "failed to stat manifest")
	}
	data, err := os.ReadFile(d.ManifestPath)
	if err != nil {
		return errors.Wrap(err, "failed to read manifest")
	}
	m, err := parseManifest(data)
	if err != nil {
		return errors.Wrap(err, "failed to parse manifest")
	}
	root := &mountNode{name: "root", children: map[string]*mountNode{}}
	repos := make([]*manifestRepo, 0, len(m.Repos))

	storageMount := utils.FixAndCleanPath(utils.GetActualMountPath(d.GetStorage().MountPath))
	for i := range m.Repos {
		repo := &m.Repos[i]
		repo.seq = i
		repo.Path = utils.FixAndCleanPath(repo.Path)
		if repo.Path == "/" {
			return errors.New("path is required for each manifest line")
		}
		if repo.Repo == "" {
			return fmt.Errorf("repo is required for path %s", repo.Path)
		}
		if !utils.IsSubPath(storageMount, repo.Path) {
			continue
		}
		repo.localMountPath = localMountPath(storageMount, repo.Path)
		if err := addRepo(root, repo); err != nil {
			return err
		}
		repos = append(repos, repo)
	}
	sort.SliceStable(repos, func(i, j int) bool {
		if len(repos[i].localMountPath) == len(repos[j].localMountPath) {
			return repos[i].seq < repos[j].seq
		}
		return len(repos[i].localMountPath) > len(repos[j].localMountPath)
	})
	if len(repos) == 0 {
		return fmt.Errorf("manifest has no repos under storage mount_path %s", storageMount)
	}
	d.mutex.Lock()
	d.root = root
	d.repos = repos
	d.manifestModTime = info.ModTime()
	d.manifestSize = info.Size()
	if d.treeCache == nil {
		d.treeCache = make(map[string][]hfTreeEntry)
	}
	if d.missingTreeCache == nil {
		d.missingTreeCache = make(map[string]struct{})
	}
	d.objectCache = make(map[string]repoMatch)
	d.mutex.Unlock()
	return nil
}

func parseManifest(data []byte) (*manifest, error) {
	data = bytes.TrimSpace(data)
	data = bytes.TrimPrefix(data, []byte{0xef, 0xbb, 0xbf})
	if len(data) == 0 {
		return nil, errors.New("manifest is empty")
	}

	m := &manifest{}
	scanner := bufio.NewScanner(bytes.NewReader(data))
	lineNum := 0
	for scanner.Scan() {
		lineNum++
		line := bytes.TrimSpace(scanner.Bytes())
		if len(line) == 0 {
			continue
		}
		var repo manifestRepo
		if err := json.Unmarshal(line, &repo); err != nil {
			return nil, fmt.Errorf("line %d: %w", lineNum, err)
		}
		m.Repos = append(m.Repos, repo)
	}
	if err := scanner.Err(); err != nil {
		return nil, err
	}
	return m, nil
}

func addRepo(root *mountNode, repo *manifestRepo) error {
	node := root
	for _, part := range pathParts(repo.localMountPath) {
		if node.children == nil {
			node.children = map[string]*mountNode{}
		}
		child, ok := node.children[part]
		if !ok {
			child = &mountNode{name: part, children: map[string]*mountNode{}}
			node.children[part] = child
		}
		node = child
	}
	node.repos = append(node.repos, repo)
	return nil
}

func (d *HuggingFaceAggregate) getNode(reqPath string) *mountNode {
	reqPath = utils.FixAndCleanPath(reqPath)
	node := d.root
	for _, part := range pathParts(reqPath) {
		if node == nil || node.children == nil {
			return nil
		}
		node = node.children[part]
	}
	return node
}

type repoMatch struct {
	repo     *manifestRepo
	repoPath string
}

func (d *HuggingFaceAggregate) matchRepos(reqPath string) []repoMatch {
	reqPath = utils.FixAndCleanPath(reqPath)
	matches := make([]repoMatch, 0, 1)
	for _, repo := range d.repos {
		if utils.IsSubPath(repo.localMountPath, reqPath) {
			repoPath := strings.TrimPrefix(reqPath, repo.localMountPath)
			matches = append(matches, repoMatch{
				repo:     repo,
				repoPath: utils.FixAndCleanPath(repoPath),
			})
		}
	}
	return matches
}

func (d *HuggingFaceAggregate) getRepoObj(ctx context.Context, match repoMatch, reqPath string) (model.Obj, error) {
	parentPath, name := stdpath.Split(match.repoPath)
	if name == "" {
		return &model.Object{
			Path:     reqPath,
			Name:     stdpath.Base(reqPath),
			Size:     0,
			Modified: d.GetStorage().Modified,
			IsFolder: true,
		}, nil
	}
	entries, ok, err := d.listExistingDir(ctx, match.repo, parentPath)
	if err != nil {
		return nil, err
	}
	if !ok {
		return nil, errs.ObjectNotFound
	}
	for _, entry := range entries {
		if stdpath.Base(entry.Path) == name {
			return d.entryToObj(match.repo, entry), nil
		}
	}
	return nil, errs.ObjectNotFound
}

func (d *HuggingFaceAggregate) listExistingDir(ctx context.Context, repo *manifestRepo, repoPath string, refresh ...bool) ([]hfTreeEntry, bool, error) {
	repoPath = utils.FixAndCleanPath(repoPath)
	if utils.PathEqual(repoPath, "/") {
		entries, err := d.listRepo(ctx, repo, repoPath, refresh...)
		return entries, err == nil, err
	}

	current := "/"
	for _, part := range pathParts(repoPath) {
		entries, err := d.listRepo(ctx, repo, current, refresh...)
		if err != nil {
			return nil, false, err
		}
		var next *hfTreeEntry
		for i := range entries {
			entry := &entries[i]
			if entry.Type == "directory" && stdpath.Base(entry.Path) == part {
				next = entry
				break
			}
		}
		if next == nil {
			return nil, false, nil
		}
		current = utils.FixAndCleanPath(next.Path)
	}

	entries, err := d.listRepo(ctx, repo, current, refresh...)
	return entries, err == nil, err
}

func (d *HuggingFaceAggregate) setObjectCache(reqPath string, match repoMatch) {
	d.mutex.Lock()
	if d.objectCache == nil {
		d.objectCache = make(map[string]repoMatch)
	}
	d.objectCache[utils.FixAndCleanPath(reqPath)] = match
	d.mutex.Unlock()
}

func matchInRepos(match repoMatch, matches []repoMatch) bool {
	for _, candidate := range matches {
		if candidate.repo == match.repo && candidate.repoPath == match.repoPath {
			return true
		}
	}
	return false
}

func (d *HuggingFaceAggregate) listRepo(ctx context.Context, repo *manifestRepo, repoPath string, refresh ...bool) ([]hfTreeEntry, error) {
	repoType := normalizeRepoType(repo.RepoType)
	reqPath := strings.TrimPrefix(utils.FixAndCleanPath(repoPath), "/")
	branch := d.branch(repo)
	cacheKey := repoType + "\x00" + repo.Repo + "\x00" + branch + "\x00" + reqPath
	if !utils.IsBool(refresh...) {
		d.mutex.RLock()
		entries, ok := d.treeCache[cacheKey]
		_, missing := d.missingTreeCache[cacheKey]
		d.mutex.RUnlock()
		if ok {
			return entries, nil
		}
		if missing {
			return nil, errs.ObjectNotFound
		}
	}

	var apiURL string
	if repoType == "datasets" {
		apiURL = fmt.Sprintf("/api/datasets/%s/tree/%s/%s", repo.Repo, branch, url.PathEscape(reqPath))
	} else {
		apiURL = fmt.Sprintf("/api/models/%s/tree/%s/%s", repo.Repo, branch, url.PathEscape(reqPath))
	}
	req := d.client.R().SetContext(ctx)
	if token := d.token(repo); token != "" {
		req.SetHeader("Authorization", fmt.Sprintf("Bearer %s", token))
	}
	resp, err := req.Get(apiURL)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode() != http.StatusOK {
		if resp.StatusCode() == http.StatusNotFound {
			d.mutex.Lock()
			if d.missingTreeCache == nil {
				d.missingTreeCache = make(map[string]struct{})
			}
			d.missingTreeCache[cacheKey] = struct{}{}
			d.mutex.Unlock()
			return nil, errs.ObjectNotFound
		}
		return nil, fmt.Errorf("HTTP error: %s; %s", resp.Status(), resp.Body())
	}
	var entries []hfTreeEntry
	if err := json.Unmarshal(resp.Body(), &entries); err != nil {
		return nil, err
	}
	d.mutex.Lock()
	if d.treeCache == nil {
		d.treeCache = make(map[string][]hfTreeEntry)
	}
	d.treeCache[cacheKey] = entries
	delete(d.missingTreeCache, cacheKey)
	d.mutex.Unlock()
	return entries, nil
}

func (d *HuggingFaceAggregate) entryToObj(repo *manifestRepo, entry hfTreeEntry) model.Obj {
	isFolder := entry.Type == "directory"
	return &model.Object{
		ID:       entry.Oid,
		Path:     stdpath.Join(repo.localMountPath, entry.Path),
		Name:     stdpath.Base(entry.Path),
		Size:     entry.Size,
		Modified: time.Unix(0, 0),
		IsFolder: isFolder,
	}
}

func (d *HuggingFaceAggregate) token(repo *manifestRepo) string {
	return repo.Token
}

func (d *HuggingFaceAggregate) branch(repo *manifestRepo) string {
	if repo.Branch != "" {
		return repo.Branch
	}
	return d.Branch
}

func nodeToObj(node *mountNode, reqPath string, modified time.Time) model.Obj {
	return &model.Object{
		Path:     utils.FixAndCleanPath(reqPath),
		Name:     node.name,
		Size:     0,
		Modified: modified,
		IsFolder: true,
	}
}

func localMountPath(storageMount, repoMount string) string {
	if utils.PathEqual(storageMount, repoMount) {
		return "/"
	}
	return utils.FixAndCleanPath(strings.TrimPrefix(repoMount, utils.PathAddSeparatorSuffix(storageMount)))
}

func pathParts(p string) []string {
	p = strings.Trim(utils.FixAndCleanPath(p), "/")
	if p == "" {
		return nil
	}
	return strings.Split(p, "/")
}

func normalizeRepoType(repoType string) string {
	if repoType == "datasets" {
		return "datasets"
	}
	return "models"
}

var _ driver.Driver = (*HuggingFaceAggregate)(nil)
var _ driver.Getter = (*HuggingFaceAggregate)(nil)
var _ driver.GetRooter = (*HuggingFaceAggregate)(nil)
