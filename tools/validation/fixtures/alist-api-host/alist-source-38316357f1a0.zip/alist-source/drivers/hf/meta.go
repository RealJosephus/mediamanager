package hf

import (
	"github.com/alist-org/alist/v3/internal/driver"
	"github.com/alist-org/alist/v3/internal/op"
)

type Addition struct {
	driver.RootPath
	RepoType string `json:"repo_type" type:"select" required:"true" options:"models,datasets" default:"models"`
	RepoId   string `json:"repo_id" required:"true"`
	Token    string `json:"token"`
}

var config = driver.Config{
	Name:              "HuggingFace",
	LocalSort:         true,
	OnlyLocal:         false,
	OnlyProxy:         false,
	NoCache:           false,
	NoUpload:          true,
	NeedMs:            false,
	DefaultRoot:       "/",
	CheckStatus:       false,
	Alert:             "",
	NoOverwriteUpload: false,
}

func init() {
	op.RegisterDriver(func() driver.Driver {
		return &HuggingFace{}
	})
}
