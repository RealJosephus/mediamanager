package hf

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"path"
	"strings"
	"time"

	"github.com/alist-org/alist/v3/internal/driver"
	"github.com/alist-org/alist/v3/internal/errs"
	"github.com/alist-org/alist/v3/internal/model"
	"github.com/alist-org/alist/v3/pkg/utils"
	"github.com/go-resty/resty/v2"
)

type HuggingFace struct {
	model.Storage
	Addition
	client *resty.Client
}

func (d *HuggingFace) Config() driver.Config {
	return config
}

func (d *HuggingFace) GetAddition() driver.Additional {
	return &d.Addition
}

func (d *HuggingFace) Init(ctx context.Context) error {
	d.client = resty.New().
		SetBaseURL("http://127.0.0.1:23678").
 		SetHeader("User-Agent", "alist")
	if d.Token != "" {
		d.client.SetHeader("Authorization", fmt.Sprintf("Bearer %s", d.Token))
	}
	return nil
}

func (d *HuggingFace) Drop(ctx context.Context) error {
	return nil
}

func (d *HuggingFace) List(ctx context.Context, dir model.Obj, args model.ListArgs) ([]model.Obj, error) {
	repoType := d.RepoType
	if repoType != "models" && repoType != "datasets" {
		repoType = "models"
	}
	reqPath := strings.TrimPrefix(dir.GetPath(), "/")
	var apiURL string
	if repoType == "datasets" {
		apiURL = fmt.Sprintf("/api/datasets/%s/tree/main/%s", d.RepoId, url.PathEscape(reqPath))
	} else {
		apiURL = fmt.Sprintf("/api/models/%s/tree/main/%s", d.RepoId, url.PathEscape(reqPath))
	}
	resp, err := d.client.R().
		Get(apiURL)
	if err != nil {
		return nil, err
	}
	if resp.StatusCode() != http.StatusOK {
		return nil, fmt.Errorf("HTTP error: %s; %s", resp.Status(), resp.Body())
	}
	var entries []struct {
		Type string `json:"type"`
		Oid  string `json:"oid"`
		Size int64  `json:"size"`
		Path string `json:"path"`
	}
	err = json.Unmarshal(resp.Body(), &entries)
	if err != nil {
		return nil, err
	}
	objs := []model.Obj{}
	defaultTime := time.Unix(0, 0)
	for _, entry := range entries {
		isFolder := entry.Type == "directory"
		obj := &model.Object{
			ID:       entry.Oid,
			Path:     "/" + entry.Path,
			Name:     path.Base(entry.Path),
			Size:     entry.Size,
			Modified: defaultTime,
			IsFolder: isFolder,
		}
		objs = append(objs, obj)
	}
	return objs, nil
}

func (d *HuggingFace) Link(ctx context.Context, file model.Obj, args model.LinkArgs) (*model.Link, error) {
	repoType := d.RepoType
	if repoType != "models" && repoType != "datasets" {
		repoType = "models"
	}
	filePath := strings.TrimPrefix(file.GetPath(), "/")
	var downloadURL string
	if repoType == "datasets" {
		downloadURL = fmt.Sprintf("http://127.0.0.1:23678/datasets/%s/resolve/main/%s", d.RepoId, url.PathEscape(filePath))
	} else {
		downloadURL = fmt.Sprintf("http://127.0.0.1:23678/%s/resolve/main/%s", d.RepoId, url.PathEscape(filePath))
	}
	link := &model.Link{
		URL:    downloadURL,
		Header: http.Header{},
		Concurrency: 4,
		PartSize:    8 * utils.MB,
	}
	if d.Token != "" {
		link.Header.Set("Authorization", fmt.Sprintf("Bearer %s", d.Token))
	}
	return link, nil
}

func (d *HuggingFace) MakeDir(ctx context.Context, parentDir model.Obj, dirName string) error {
	return errs.NotSupport
}

func (d *HuggingFace) Move(ctx context.Context, srcObj, dstDir model.Obj) error {
	return errs.NotSupport
}

func (d *HuggingFace) Rename(ctx context.Context, srcObj model.Obj, newName string) error {
	return errs.NotSupport
}

func (d *HuggingFace) Copy(ctx context.Context, srcObj, dstDir model.Obj) error {
	return errs.NotSupport
}

func (d *HuggingFace) Remove(ctx context.Context, obj model.Obj) error {
	return errs.NotSupport
}

func (d *HuggingFace) Put(ctx context.Context, dstDir model.Obj, stream model.FileStreamer, up driver.UpdateProgress) error {
	return errs.NotSupport
}

var _ driver.Driver = (*HuggingFace)(nil)
