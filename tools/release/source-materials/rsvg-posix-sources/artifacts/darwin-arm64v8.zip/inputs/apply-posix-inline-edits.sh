#!/usr/bin/env bash
set -eu
sed -i'.bak' "/image = /s/, \"gif\", \"webp\"//" rsvg/Cargo.toml
# We build Cairo with `-Dzlib=disabled`, which implicitly disables the PDF/PostScript surface backends
sed -i'.bak' "/cairo-rs = /s/, \"pdf\", \"ps\"//" {librsvg-c,rsvg}/Cargo.toml
# https://gitlab.gnome.org/GNOME/librsvg/-/merge_requests/1066#note_2356762
sed -i'.bak' "/^if host_system in \['windows'/s/, 'linux'//" meson.build
# Regenerate the lockfile after making the above changes
