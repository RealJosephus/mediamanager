mkdir ${DEPS}/rsvg
$CURL https://download.gnome.org/sources/librsvg/$(without_patch $VERSION_RSVG)/librsvg-${VERSION_RSVG}.tar.xz | tar xJC ${DEPS}/rsvg --strip-components=1
cd ${DEPS}/rsvg
# Disallow GIF and WebP embedded in SVG images
sed -i'.bak' "/image = /s/, \"gif\", \"webp\"//" rsvg/Cargo.toml
# We build Cairo with `-Dzlib=disabled`, which implicitly disables the PDF/PostScript surface backends
sed -i'.bak' "/cairo-rs = /s/, \"pdf\", \"ps\"//" {librsvg-c,rsvg}/Cargo.toml
# https://gitlab.gnome.org/GNOME/librsvg/-/merge_requests/1066#note_2356762
sed -i'.bak' "/^if host_system in \['windows'/s/, 'linux'//" meson.build
# Regenerate the lockfile after making the above changes
cargo update --workspace
# Remove the --static flag from the PKG_CONFIG env since Rust does not
# parse that correctly.
PKG_CONFIG=${PKG_CONFIG/ --static/} meson setup _build --default-library=static --buildtype=plain --strip --prefix=${TARGET} ${MESON} \
  -Dintrospection=disabled -Dpixbuf{,-loader}=disabled -Drsvg-convert=disabled -Ddocs=disabled -Dvala=disabled -Dtests=false \
  ${RUST_TARGET:+-Dtriplet=$RUST_TARGET}
meson install -C _build --tag devel
