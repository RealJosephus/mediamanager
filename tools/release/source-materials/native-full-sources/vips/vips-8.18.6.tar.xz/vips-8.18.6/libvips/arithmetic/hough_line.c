/* hough transform for lines
 *
 * 7/3/14
 * 	- from hist_find.c
 * 1/2/18
 * 	- change width to 0 - 180
 */

/*

	This file is part of VIPS.

	VIPS is free software; you can redistribute it and/or modify
	it under the terms of the GNU Lesser General Public License as published by
	the Free Software Foundation; either version 2 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU Lesser General Public License for more details.

	You should have received a copy of the GNU Lesser General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
	02110-1301  USA

 */

/*

	These files are distributed with VIPS - http://www.vips.ecs.soton.ac.uk

 */

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif /*HAVE_CONFIG_H*/
#include <glib/gi18n-lib.h>

#include <string.h>
#include <math.h>

#include <vips/vips.h>

#include "statistic.h"
#include "hough.h"

typedef struct _VipsHoughLine {
	VipsHough parent_instance;

	/* Size of parameter space.
	 */
	int width;
	int height;

	/* LUT for this transform.
	 */
	double *sin;

} VipsHoughLine;

typedef VipsHoughClass VipsHoughLineClass;

G_DEFINE_TYPE(VipsHoughLine, vips_hough_line, VIPS_TYPE_HOUGH);

static int
vips_hough_line_build(VipsObject *object)
{
	VipsHoughLine *hough_line = (VipsHoughLine *) object;
	int width = hough_line->width;

	if (!(hough_line->sin = VIPS_ARRAY(object, 2 * width, double)))
		return -1;

	/* Map width to 180 degrees, width * 2 to 360.
	 */
	for (int i = 0; i < 2 * width; i++)
		hough_line->sin[i] = sin(2 * VIPS_PI * i / (2 * width));

	if (VIPS_OBJECT_CLASS(vips_hough_line_parent_class)->build(object))
		return -1;

	return 0;
}

static int
vips_hough_line_init_accumulator(VipsHough *hough, VipsImage *accumulator)
{
	VipsHoughLine *hough_line = (VipsHoughLine *) hough;

	vips_image_init_fields(accumulator,
		hough_line->width, hough_line->height, 1,
		VIPS_FORMAT_UINT, VIPS_CODING_NONE,
		VIPS_INTERPRETATION_MATRIX,
		1.0, 1.0);

	return 0;
}

/* Cast votes for all lines passing through x, y.
 */
static void
vips_hough_line_vote(VipsHough *hough, VipsImage *accumulator, int x, int y)
{
	VipsHoughLine *hough_line = (VipsHoughLine *) hough;
	VipsStatistic *statistic = (VipsStatistic *) hough;

	// normalise (x, y) to diagonal size of input image
	int xs = statistic->ready->Xsize;
	int ys = statistic->ready->Ysize;
	double d = sqrt(xs * xs + ys * ys);
	double xd = (double) x / d;
	double yd = (double) y / d;

	// size of hough space
	int width = hough_line->width;
	int height = hough_line->height;
	guint *data = (guint *) accumulator->data;

	for (int i = 0; i < width; i++) {
		int i90 = i + width / 2;
		double r = xd * hough_line->sin[i90] + yd * hough_line->sin[i];
		int ri = (r + 1) * (height / 2.0);

		g_assert(ri >= 0 && ri < height);
		data[i + ri * width] += 1;
	}
}

static void
vips_hough_line_class_init(VipsHoughClass *class)
{
	GObjectClass *gobject_class = (GObjectClass *) class;
	VipsObjectClass *object_class = (VipsObjectClass *) class;
	VipsHoughClass *hclass = (VipsHoughClass *) class;

	gobject_class->set_property = vips_object_set_property;
	gobject_class->get_property = vips_object_get_property;

	object_class->nickname = "hough_line";
	object_class->description = _("find hough line transform");
	object_class->build = vips_hough_line_build;

	hclass->init_accumulator = vips_hough_line_init_accumulator;
	hclass->vote = vips_hough_line_vote;

	VIPS_ARG_INT(class, "width", 110,
		_("Width"),
		_("Horizontal size of parameter space"),
		VIPS_ARGUMENT_OPTIONAL_INPUT,
		G_STRUCT_OFFSET(VipsHoughLine, width),
		1, 100000, 256);

	VIPS_ARG_INT(class, "height", 111,
		_("Height"),
		_("Vertical size of parameter space"),
		VIPS_ARGUMENT_OPTIONAL_INPUT,
		G_STRUCT_OFFSET(VipsHoughLine, height),
		1, 100000, 256);
}

static void
vips_hough_line_init(VipsHoughLine *hough_line)
{
	hough_line->width = 256;
	hough_line->height = 256;
}

/**
 * vips_hough_line: (method)
 * @in: input image
 * @out: (out): output image
 * @...: `NULL`-terminated list of optional named arguments
 *
 * Find the line Hough transform for @in. @in must have one band. @out has one
 * band, with pixels being the number of votes for that line. The X dimension
 * of @out is the line angle in 0 - 180 degrees, the Y dimension is the
 * distance of the closest part of that line to the origin in the top-left.
 *
 * Use @width @height to set the size of the parameter space image (@out),
 * that is, how accurate the line determination should be.
 *
 * ::: tip "Optional arguments"
 *     * @width: `gint`, horizontal size of parameter space
 *     * @height: `gint`, vertical size of parameter space
 *
 * ::: seealso
 *     [method@Image.hough_circle].
 *
 * Returns: 0 on success, -1 on error
 */
int
vips_hough_line(VipsImage *in, VipsImage **out, ...)
{
	va_list ap;
	int result;

	va_start(ap, out);
	result = vips_call_split("hough_line", ap, in, out);
	va_end(ap);

	return result;
}
