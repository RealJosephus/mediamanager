# This file is part of MXE. See LICENSE.md for licensing information.

PKG             := llvm-mingw
$(PKG)_WEBSITE  := https://github.com/mstorsjo/llvm-mingw
$(PKG)_DESCR    := An LLVM/Clang/LLD based mingw-w64 toolchain
$(PKG)_IGNORE   :=
$(PKG)_VERSION  := 20260602
$(PKG)_CHECKSUM := ac037f1ccb45bbff9ae202baa6840ebb6e178b56e2ea72d501486288548d92e9
$(PKG)_GH_CONF  := mstorsjo/llvm-mingw/tags
$(PKG)_DEPS     := mingw-w64

# The minimum Windows version we support is Windows 7, as libc++ uses
# TryAcquireSRWLockExclusive which didn't exist until Windows 7 - see:
# https://github.com/mstorsjo/llvm-mingw/commit/dcf34a9a35ee3d490a85bdec02999cf96615d406
# https://github.com/mstorsjo/llvm-mingw/blob/274a30cff5bf96efeb6b6c7a5a4783fa6fda1e69/build-mingw-w64.sh#L19-L20
# Headers are installed in $(PREFIX)/$(TARGET)/$(PROCESSOR)-w64-mingw32
# to allow distributing the /include and /lib directories.
define $(PKG)_BUILD_mingw-w64
    # Ensure that mingw-w64 is built without any optimizations
    $(eval unexport CFLAGS)
    $(eval unexport CXXFLAGS)
    $(eval unexport LDFLAGS)

    # install the usual wrappers
    $($(PKG)_PRE_BUILD)

    # install mingw-w64 headers
    $(call PREPARE_PKG_SOURCE,mingw-w64,$(BUILD_DIR))
    mkdir '$(BUILD_DIR).headers'
    cd '$(BUILD_DIR).headers' && '$(BUILD_DIR)/$(mingw-w64_SUBDIR)/mingw-w64-headers/configure' \
        --host='$(TARGET)' \
        --prefix='$(PREFIX)/$(TARGET)/$(PROCESSOR)-w64-mingw32' \
        --enable-idl \
        --with-default-msvcrt=ucrt \
        --with-default-win32-winnt=0x601 \
        $(mingw-w64-headers_CONFIGURE_OPTS)
    $(MAKE) -C '$(BUILD_DIR).headers' install

    # build mingw-w64-crt
    mkdir '$(BUILD_DIR).crt'
    cd '$(BUILD_DIR).crt' && '$(BUILD_DIR)/$(mingw-w64_SUBDIR)/mingw-w64-crt/configure' \
        --host='$(TARGET)' \
        --prefix='$(PREFIX)/$(TARGET)/$(PROCESSOR)-w64-mingw32' \
        --with-default-msvcrt=$(if $(findstring .debug,$(TARGET)),ucrtbased,ucrt) \
        --enable-silent-rules \
        @mingw-crt-config-opts@
    $(MAKE) -C '$(BUILD_DIR).crt' -j '$(JOBS)'
    $(MAKE) -C '$(BUILD_DIR).crt' -j 1 $(INSTALL_STRIP_TOOLCHAIN)

    # Create empty dummy archives, to avoid failing when the compiler
    # driver adds "-lpthread" or "-lssp -lssp_nonshared" when linking.
    '$(PREFIX)/$(BUILD)/bin/llvm-ar' rcs '$(PREFIX)/$(TARGET)/$(PROCESSOR)-w64-mingw32/lib/libpthread.a'
    '$(PREFIX)/$(BUILD)/bin/llvm-ar' rcs '$(PREFIX)/$(TARGET)/$(PROCESSOR)-w64-mingw32/lib/libssp.a'
    '$(PREFIX)/$(BUILD)/bin/llvm-ar' rcs '$(PREFIX)/$(TARGET)/$(PROCESSOR)-w64-mingw32/lib/libssp_nonshared.a'
endef

define $(PKG)_PRE_BUILD
    # setup target wrappers
    $(foreach EXEC, addr2line ar dlltool nm objcopy ranlib strings strip, \
        ln -sf '$(PREFIX)/$(BUILD)/bin/llvm-$(EXEC)' '$(PREFIX)/$(TARGET)/bin/$(PROCESSOR)-w64-mingw32-$(EXEC)'; \
        (echo '#!/bin/sh'; \
         echo 'exec "$(PREFIX)/$(TARGET)/bin/$(PROCESSOR)-w64-mingw32-$(EXEC)" "$$@"') \
                 > '$(PREFIX)/bin/$(TARGET)-$(EXEC)'; \
        chmod 0755 '$(PREFIX)/bin/$(TARGET)-$(EXEC)';)

    # https://github.com/llvm/llvm-project/issues/64927
    ln -sf '$(PREFIX)/$(BUILD)/bin/llvm-windres' '$(PREFIX)/$(TARGET)/bin/$(PROCESSOR)-w64-mingw32-windres'
    (echo '#!/bin/sh'; \
     echo 'exec "$(PREFIX)/$(TARGET)/bin/$(PROCESSOR)-w64-mingw32-windres" \
         --preprocessor-arg="--sysroot=$(PREFIX)/$(TARGET)" "$$@"') \
             > '$(PREFIX)/bin/$(TARGET)-windres'
    chmod 0755 '$(PREFIX)/bin/$(TARGET)-windres'

    $(foreach EXEC, clang-target ld objdump, \
        $(INSTALL) -m755 '$(SOURCE_DIR)/wrappers/$(EXEC)-wrapper.sh' '$(PREFIX)/$(TARGET)/bin'; \
        $(SED) -i -e 's|^DEFAULT_TARGET=.*|DEFAULT_TARGET=$(PROCESSOR)-w64-mingw32|' \
                  -e 's|^DIR=.*|DIR="$(PREFIX)/$(BUILD)/bin"|' \
                  -e 's|$$FLAGS "$$@"|$$FLAGS --sysroot="$(PREFIX)/$(TARGET)" "$$@"|' '$(PREFIX)/$(TARGET)/bin/$(EXEC)-wrapper.sh';)

    $(INSTALL) -m644 '$(SOURCE_DIR)/wrappers/mingw32-common.cfg' '$(PREFIX)/$(BUILD)/bin'
    $(INSTALL) -m644 '$(SOURCE_DIR)/wrappers/$(PROCESSOR)-w64-windows-gnu.cfg' '$(PREFIX)/$(BUILD)/bin'

    $(foreach EXEC, clang clang++ gcc g++ c++, \
        ln -sf '$(PREFIX)/$(TARGET)/bin/clang-target-wrapper.sh' '$(PREFIX)/bin/$(TARGET)-$(EXEC)';)

    $(foreach EXEC, ld objdump, \
        ln -sf '$(PREFIX)/$(TARGET)/bin/$(EXEC)-wrapper.sh' '$(PREFIX)/bin/$(TARGET)-$(EXEC)';)
endef

$(PKG)_BUILD_x86_64-w64-mingw32 = $(subst @mingw-crt-config-opts@,--disable-lib32 --enable-lib64,$($(PKG)_BUILD_mingw-w64))
$(PKG)_BUILD_i686-w64-mingw32   = $(subst @mingw-crt-config-opts@,--enable-lib32 --disable-lib64,$($(PKG)_BUILD_mingw-w64))
$(PKG)_BUILD_aarch64-w64-mingw32 = $(subst @mingw-crt-config-opts@,--disable-lib32 --disable-lib64 --enable-libarm64,$($(PKG)_BUILD_mingw-w64))
